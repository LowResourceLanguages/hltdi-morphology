This is version 1.2 of AntiMorfo, a Python program that does morphological
analysis of Quechua words and Spanish verbs.
AntiMorfo is part of the L3 Project
(http://www.cs.indiana.edu/~gasser/Research/projects.html) of the
HLTDI Research Group (http://www.cs.indiana.edu/~gasser/Research/hltdi.html).

To install AntiMorfo, extract the files from the archive. Then go to
the directory AntiMorfo-1.2 and do 

  python setup.py install

making sure that you are using Python 3.

For information about using the program, see the manual that came with
the distribution: antimorfo1.2.pdf.
