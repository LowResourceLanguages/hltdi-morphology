This is version 0.9.6 of MorfoMelayu, a Python program that does morphological
analysis of Malay words.
MorfoMelayu is part of the L3 Project
(http://www.cs.indiana.edu/~gasser/Research/projects.html).

To install MorfoMelayu, extract the files from the archive. Then go to
the directory MorfoMelayu-0.9.6 and do 

  python setup.py install

making sure that you are using Python 3 or 3.1.
