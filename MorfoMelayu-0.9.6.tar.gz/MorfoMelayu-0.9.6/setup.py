#!/usr/bin/env python

import sys

from distutils.core import setup

setup(name='MorfoMelayu',
      version='0.9.6',
      description='Morphological analyzer for Bahasa Melayu',
      author='Michael Gasser',
      author_email='gasser@cs.indiana.edu',
      url='http://www.cs.indiana.edu/~gasser/Research/software.html',
      license="GPL v3",
      packages=['l3', 'l3.morpho'],
      package_data = {'l3': ['FST/*.fst', 'Data/Ms/ms.txt',
                             'FST/Ms/*.fst', 'FST/Ms/*.lex', 'FST/Ms/*.cas'],
                      }
     )
