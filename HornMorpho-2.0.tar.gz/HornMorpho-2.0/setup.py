#!/usr/bin/env python

import sys

from distutils.core import setup

setup(name='HornMorpho',
      version='2.0',
      description='Morphological analyzer/generator for Amharic, Oromo, Tigrinya',
      author='Michael Gasser',
      author_email='gasser@cs.indiana.edu',
      url='http://www.cs.indiana.edu/~gasser/Research/software.html',
      license="GPL v3",
      packages=['l3', 'l3.morpho', 'l3.morpho.geez'],
      package_data = {'l3': ['FST/*.fst', 'Data/Am/am.txt', 'Data/Ti/ti.txt',
                             'FST/Am/*.fst', 'FST/Am/*.lex', 'FST/Am/*.cas',
                             'FST/Ti/*.fst', 'FST/Ti/*.lex', 'FST/Ti/*.cas',
                             'FST/Om/*.fst', 'FST/Om/*.lex', 'FST/Om/*.cas'],
                      'l3.morpho.geez': ['*.txt']},
     )
